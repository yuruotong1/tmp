import os

import pytest

from mtf.core.context import Context
from mtf.core.logger import log
from mtf.core.test_base import TestBase
from mtf.core.utils import Utils


class TestCaseDemo(TestBase):
    cur_dir = os.path.abspath(__file__)
    context = Context()
    context.load("1.yaml")


    # done: testcase name
    @pytest.mark.parametrize(
        "testcase",
        context.store.testcases.values(),
        ids=context.store.testcases.keys()
    )
    def test_param(self, testcase):
        self.context.run_steps_by_testcase(testcase)
