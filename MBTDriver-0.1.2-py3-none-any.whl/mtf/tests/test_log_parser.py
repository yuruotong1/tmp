import re

from mtf.core.log_parser import LogParser
from mtf.core.logger import log
from mtf.core.utils import Utils


def test_parse():
    pattern = {
        'regex': [
            'key2=(?P<id>\w+)',
            '(?P<key>[a-z]+)=(?P<value>\w+)',
            'begin test (?P<test_name>\w+)',
            'begin step (?P<step_name>\w+)',
        ]
    }
    parser = LogParser.log(pattern)
    log.debug(Utils.to_json_str(parser.parse('debuglog.txt')))


def test_regex():
    content = '''
    a bc edf 1234 
    7 8 9 
    '''
    res = 1
    while True:
        res = re.search('(?P<key>12342222)', content)
        if res is None:
            break
        else:
            pass
        log.debug(res.groupdict())
        log.debug(res.end())
        content = content[res.end():]
        log.debug(content)


import pytest

from mtf.core.context import Context
from mtf.core.logger import log
from mtf.core.test_base import TestBase


class TestCaseDemo(TestBase):
    context = Context()
    context.load(str(__name__).split('.')[-1] + '.yaml')

    # done: testcase name
    @pytest.mark.parametrize(
        "testcase",
        context.store.testcases.values(),
        ids=context.store.testcases.keys()
    )
    def test_param(self, testcase):
        self.context.run_steps_by_testcase(testcase)
