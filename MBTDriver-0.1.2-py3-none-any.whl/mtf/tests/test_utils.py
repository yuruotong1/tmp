import asyncio
import math
import platform
import subprocess
from time import sleep

import jinja2
import re

import yaml
from _pytest.fixtures import FixtureRequest

from csrmock.core.mitm.mitm_json import MitmJson
from csrmock.core.mitm.mitm_tcp import MitmTcp
from csrmock.core.tcp_server_echo import EchoServer
from mtf.core.logger import log
from mtf.core.utils import Utils


# 推荐使用jinja2
def test_jinja():
    data = {'a': "3", 'b': 4}
    assert Utils.jinja("{{a}} {{b}}", data) == "3 4"
    assert Utils.jinja("{{b.c}}", {'a': "3", 'b': {"c": 1}}) == "1"
    assert Utils.jinja("{{math.floor(6.4)}}", {"math": math}) == "6"
    assert Utils.jinja("{{math.floor(6.4)}}", globals()) == "6"
    assert Utils.jinja("{{true}}", globals()) == str(True)
    assert Utils.jinja("a b {{a}}", data) == "a b 3"


def test_mustache():
    assert Utils.mustache("{{a}} {{b}}", {'a': "3", 'b': 4}) == "3 4"
    assert Utils.mustache("{{b.c}}", {'a': "3", 'b': {"c": 1}}) == "1"
    assert Utils.template("{{math.floor(6.4)}}", globals()) == "6"


def test_jinja2():
    for f in jinja2.Template("${1+2} ${a+b}").generate(a=1, b=2):
        print(f)


def test_to_json():
    d = {'a': b'123'}
    d = [1, 2, 3]
    print(Utils.to_json_str(d))
    print(Utils.to_json_object(d))


def test_nc():
    print(Utils.nc('ceshiren.com', 80, 'GET / HTTP/2\nHost: ceshiren.com'))


def test_get_yaml_files():
    print(Utils.get_yaml_files("../../csrmock/tests"))


def test_load():
    print(Utils.load("test_branch"))
    print(Utils().load("test_branch"))


def test_load_yaml():
    r = Utils.load_yaml("test_branch.yaml")
    assert r['test_if'] is not None

    assert 'sub_dir' in Utils.load('sub_1.yaml')


def test_recursion():
    data = {
        'a': {
            'b': {
                'setup': [1, 2, 3]
            }
        }
    }

    yaml_str = '''
test_sub_setup2:
  - params:
      a: [2, 2, 2]
      b: [1, 3, 3]
      c: [2, 6, 4]
      d: [1, 4, 7]

  - var:
      prex: $(a+b)
  - if: $(prex>c)
    true:
      - if: $(prex>d)
        true:
          - setup:
              - log: setup ${a} ${b} ${prex}
          - log: prex>d demo ${a} ${b} ${prex} ${c} ${d}
          - exec: g = a + b
          - assert: $(g >= a +b )
          - assert: $(prex>d)
        false:
          - log: prex<=d
          - assert: $(prex<=d)
    false:
      - if: $(prex>d)
        true:
          - setup:
              - log: setup ${a} ${b} ${prex}
          - log: prex>d demo ${a} ${b} ${prex} ${c} ${d}
          - assert: $(prex>d)
        false:
          - setup:
              - log: setup ${a} ${b} ${prex}
          - log: prex<=d demo ${a} ${b} ${prex} ${c} ${d}
          - assert: $(prex<=d)
'''

    data = yaml.load(yaml_str)
    print(data)
    print(Utils.recursion(data))
    found = False
    for k in Utils.recursion(data):
        if isinstance(k, dict):
            if 'setup' in k.keys():
                found = True
                break
    assert found == True


def test_shell():
    if platform.system() == 'Windows':
        r = Utils.shell(
            "echo sss"
        )
    else:
        r = Utils.shell(
            "ls dd",
            "echo sss"
        )
    assert 'sss' in r


def test_process():
    # res = subprocess.check_output(
    #     'ls dddd ; exit 0;',
    #     stderr=subprocess.STDOUT,
    #     stdout=subprocess.PIPE,
    #     shell=True
    # )
    if platform.system() == 'Windows':
        cmd = 'dir ddd'
    else:
        cmd = 'ls ddd'
    r = subprocess.run(
        cmd,
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        shell=True
    ).stdout
    if platform.system() == 'Windows':
        r = r.decode('gbk')
        assert '找不到' in r
    else:
        r = r.decode('utf-8')
        assert 'No such' in r


def test_load():
    import csrmock.core.mitm.mitm_json
    f = csrmock.core.mitm.mitm_json.MitmJson.main

    # EchoServer().start_in_background()


def test_asyncio():
    print('before fun')

    async def fun():
        print('fun')
        sleep(2)
        print('finish')

    print('after fun')

    asyncio.run(fun())
    print('run finish')
