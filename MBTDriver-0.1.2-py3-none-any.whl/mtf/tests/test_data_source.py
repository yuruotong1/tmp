import os

import pandas
import pytest

from mtf.core.data_source import DataSource
from mtf.core.utils import Utils


def test_load_excel():
    sheet1 = pandas.read_excel(Utils.load('demo.xlsx'), 'Sheet1')
    assert sheet1.to_dict(orient='records')[1]['b'] == 'b2'

    sheet2 = pandas.read_excel(Utils.load('demo.xlsx'), 'Sheet2')
    assert sheet2.to_dict(orient='records')[0]['地区'] == '山东'


def test_data_source_load():
    assert Utils.load_data('demo.xlsx', 'Sheet1')['b'][1] == 'b2'
    a = Utils.load_data('demo.xlsx', 'Sheet2')
    assert Utils.load_data('demo.xlsx', 'Sheet2')['地区'][0] == '山东'
    assert Utils.load_data('demo.csv')['地区'][0] == '山东'
    with pytest.raises(KeyError):
        assert Utils.load_data('demo.csv', 1, 2)['id'][0]
    assert Utils.load_data('demo.yaml')['data']['a'] == [11, 22, 33]
    assert Utils.load_data('demo.json')['data']['a'] == [11, 22, 33]
    assert Utils.load_data('sqlite:///' + Utils.get_project_dir() + '\\tests\\test_data\\test.db', 'COMPANY')[
               1].NAME == 'Allen'


def test_get_set_xml():
    data_source = DataSource()
    data_source.load_xml(Utils.load('demo.xml'))
    data_source.set_text(r"//NV[@ID='47674']//VALUE", 20)
    assert data_source.find_text_by_xpath(r"//NV[@ID='47674']//VALUE") == 20


def test_save_xml(tmpdir):
    tmp_path = "test_save_xml.xml"
    from xml.etree.ElementTree import Element, SubElement, ElementTree
    root = Element('root')
    head = SubElement(root, 'head')
    head.text = 'hello123'
    tree = ElementTree(root)
    tree.write(tmp_path, encoding="utf-8", xml_declaration=True)
    data_source = DataSource()
    data_source.load_xml(tmp_path)
    data_source.update_xml(r"//head", "20")
    data_source.load_xml(tmp_path)
    assert data_source.find_text_by_xpath("//head") == '20'

