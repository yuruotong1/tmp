import os
from copy import copy
from typing import List, Dict

import yaml

from mtf.core.context_base import ContextBase
from mtf.core.data_dynamic import DataDynamic
from mtf.core.logger import log
from mtf.core.page_object import PageObject
from mtf.core.step import Step
from mtf.core.utils import Utils, Singleton


class TestCaseStore(ContextBase):

    def __init__(self):
        self.methods: Dict[str, List[Step]] = {}
        self.testcases_param: Dict[str, List[Step]] = {}
        self.testcases: Dict[str, List[Step]] = {}
        self.setup_class: List[Step] = []
        self.teardown_class: List[Step] = []
        self.setup: List[Step] = []
        self.teardown: List[Step] = []
        self.class_pool = {}

        # 参数化的原始数据
        self.params_dict = {}
        # 生成的数据列表
        self.params_data = []

    def load(self, path) -> 'TestCaseStore':
        # todo: 支持多次load
        # self.__init__()

        # 遍历所有的yaml文件
        for path in Utils.get_yaml_files(path):
            log.debug(f'path={path}')
            methods = Utils.load_yaml(path)

            class_methods = {}

            # 遍历所有的顶层的kv结构，方法定义与用例定义
            for method_name, steps in methods.items():
                method_temp = []
                for dict in steps:
                    method_temp.append(Step(dict))

                # 如果是test_开头，认为是测试用例
                if method_name.startswith('test_'):
                    log.debug(f'testcase add {method_name}')
                    self.testcases_param[method_name] = method_temp
                    # todo: 支持内嵌setup

                #解析fixture
                elif method_name == 'setup_class':
                    log.debug(f'setup_class add')
                    self.setup_class = method_temp
                elif method_name == 'setup':
                    log.debug(f'setup add')
                    self.setup = method_temp
                elif method_name == 'teardown':
                    log.debug(f'teardown add')
                    self.teardown = method_temp
                elif method_name == 'teardown_class':
                    log.debug(f'teardown_class add')
                    self.teardown_class = method_temp
                else:
                    # 剩下的为通用方法
                    log.debug(f"method add {method_name}")
                    self.methods[method_name] = method_temp
                    class_methods[method_name] = method_temp

            # 把文件名当成class name
            class_name = path.split(os.sep)[-1].split('.')[0]
            self.method_gen(class_methods, class_name)

            # case裂变
            self.testcase_gen()

        return self

    def method_gen(self, methods, class_name):
        #生成多个继承自PageObject的子类
        PO = PageObject.class_gen(class_name, methods.keys(), self.get_context())
        self.class_pool[class_name] = PO

    def testcase_gen(self):
        # todo: 生成测试数据
        for name, steps in self.testcases_param.items():
            self.params_data = []
            step_first = steps[0]
            steps_first = []
            found = False
            for index, step in enumerate(steps):
                if 'params' in step.keys():
                    found = True
                    break

            # 更新参数化数据
            if found:
                steps_params = steps[0:index + 1]
                self.params_dict = self.get_context().run_steps(steps_params)
                log.debug(self.params_dict)
                self.params_data = self.data_gen(self.params_dict)

                # 利用参数化用例裂变
                for param_data_item in self.params_data:
                    steps_new: list = copy(steps[index:])
                    # 替换params为param
                    steps_new[0] = Step({
                        "param": param_data_item
                    })
                    log.debug("add param testcase")
                    self.testcases[f"{name} {param_data_item}"] = steps_new

            else:
                self.testcases[name] = steps

        log.debug(len(self.testcases))

    def data_gen(self, data_dict):
        # todo: 路径遍历
        # todo：all pair
        # https://docs.python.org/zh-cn/3/library/itertools.html
        return DataDynamic.data_gen(data_dict)
