import re

from mtf.core.logger import log
from mtf.core.utils import Utils


class LogParser:
    @classmethod
    def log(cls, pattern):
        return LogParser(pattern)

    def __init__(self, pattern):
        self.pattern = pattern

    def parse(self, file_name):
        path = Utils.load(file_name)
        content = open(path).read()

        data_list = []
        data = {}

        while True:
            start_list = {}
            for index, r in enumerate(self.pattern['regex']):
                res = re.search(r, content)
                if res is None:
                    continue
                else:
                    start_list[res.start()] = (index, res)
            if len(start_list.keys()) == 0:
                data_list.append(data)
                break
            else:
                pass

            min_index = min(start_list.keys())

            if start_list[min_index][0] == 0:
                if data is not None:
                    data_list.append(data)
                    data = {}
                else:
                    pass
            else:
                pass

            res = start_list[min_index][1]
            group_dict = res.groupdict()
            if 'key' in group_dict and 'value' in group_dict:
                data.update({group_dict['key']: group_dict['value']})
            else:
                data.update(group_dict)
            content = content[res.end():]

        return data_list
