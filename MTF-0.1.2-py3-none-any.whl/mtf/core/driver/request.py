# Author:Pegasus-Yang
# Time:2020/10/17 15:15
import requests


class Request:
    def __init__(self, base_url=None):
        self.session = requests.Session()
        self.base_url = base_url

    def new_session(self):
        self.session = requests.Session()

    def request(self, method, url='', skip_list=None, **kwargs):
        if not url.startswith('http') and self.base_url:
            url = self.base_url + url
        if skip_list:
            kwargs = Request._skip(skip_list, kwargs)
        res = self.session.request(method=method, url=url, **kwargs)
        return res

    def get(self, url='', **kwargs):
        return self.request('get', url=url, **kwargs)

    def post(self, url='', **kwargs):
        return self.request('post', url=url, **kwargs)

    def delete(self, url='', **kwargs):
        return self.request('delete', url=url, **kwargs)

    def put(self, url='', **kwargs):
        return self.request('put', url=url, **kwargs)

    def head(self, url='', **kwargs):
        return self.request('head', url=url, **kwargs)

    def patch(self, url='', **kwargs):
        return self.request('patch', url=url, **kwargs)

    def options(self, url='', **kwargs):
        return self.request('options', url=url, **kwargs)

    @staticmethod
    def _delete_dict(pattern, base_data):
        if not pattern:
            return base_data
        path = pattern.split('.')
        if len(path) == 1:
            if isinstance(base_data, (list, tuple)):
                pattern = int(pattern)
            base_data.pop(pattern)
        else:
            key = path[0]
            if isinstance(base_data, (list, tuple)):
                key = int(key)
            tmp_data = base_data[key]
            Request._delete_dict('.'.join(path[1:]), tmp_data)
        return base_data

    @staticmethod
    def _skip(skip_list, base_dict):
        if isinstance(skip_list, dict):
            for key, value in skip_list.items():
                if isinstance(value, str):
                    base_dict = Request._skip(str(key) + '.' + str(value), base_dict)
                elif isinstance(value, list):
                    for i in value:
                        base_dict = Request._skip(str(key) + '.' + str(i), base_dict)
            return base_dict
        elif isinstance(skip_list, list):
            for i in skip_list:
                base_dict = Request._skip(i, base_dict)
            return base_dict
        elif isinstance(skip_list, str):
            base_dict = Request._delete_dict(skip_list, base_dict)
            return base_dict
