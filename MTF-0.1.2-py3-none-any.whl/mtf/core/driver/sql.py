# Author:Pegasus-Yang
# Time:2020/10/17 7:43
import cx_Oracle
import pymysql
from pymysql.cursors import DictCursor


class SQL:
    """
    SQL数据库连接基类，封装公共的SQL数据库方法
    """

    def __init__(self, *args, **kwargs):
        self.connect = self._get_conn(*args, **kwargs)
        self.cursor = None

    def _get_conn(self, *args, **kwargs):
        pass

    def _get_cursor(self):
        if self.cursor is None:
            self.cursor = self.connect.cursor()
        return self.cursor

    def execute(self, sql, params=None):
        if params:
            return self._get_cursor().execute(sql, params)
        else:
            return self._get_cursor().execute(sql)

    def select(self, sql, params=None, result_num=None):
        self.execute(sql, params)
        result = self.result(result_num)
        self.close_cursor()
        return result

    def update(self, sql, params=None):
        self.execute(sql, params)
        self.close_cursor()
        self.commit()

    def insert(self, sql, params=None):
        self.execute(sql, params)
        self.close_cursor()
        self.commit()

    def delete(self, sql, params=None):
        self.execute(sql, params)
        self.close_cursor()
        self.commit()

    def commit(self):
        self.connect.commit()

    def result(self, num=None):
        if num is None:
            return self._get_cursor().fetchall()
        elif int(num) == 1:
            return self._get_cursor().fetchone()
        else:
            return self._get_cursor().fetchmany(int(num))

    def rollback(self):
        self.connect.rollback()

    def close_conn(self):
        self.connect.close()

    def close_cursor(self):
        if self.cursor:
            self.cursor.close()
            self.cursor = None


class MySQL(SQL):
    def _get_conn(self, *args, **kwargs) -> pymysql.Connection:
        return pymysql.connect(cursorclass=DictCursor, *args, **kwargs)


class Oracle(SQL):
    def _get_conn(self, *args, **kwargs) -> cx_Oracle.Connection:
        return cx_Oracle.connect(*args, **kwargs)

    def result(self, num=None):
        cur = self._get_cursor()
        # 将oracle查询返回数据利用rowfactory变更为字典结构
        columns = [col[0] for col in cur.description]
        cur.rowfactory = lambda *args: dict(zip(columns, args))
        if num is None:
            return cur.fetchall()
        elif int(num) == 1:
            return cur.fetchone()
        else:
            return cur.fetchmany(int(num))
