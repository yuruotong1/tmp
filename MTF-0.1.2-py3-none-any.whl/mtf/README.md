# MTF
model base testing framework


## example

//todo: 补充selenium app requests的示例

## quick start
- 用例格式
- 步骤介绍
- 关键字
- 断言
- 运行

## 特性介绍

### 测试用例
- [基本使用](../mtf/tests/test_demo_basic.yaml)
- [参数化例子](../mtf/tests/test_demo_params.yaml)
- [控制结构](../mtf/tests/test_branch.yaml)
- [高级数据驱动](tests/test_data_gen.yaml)
- [page object模式](../mtf/tests/test_po_case.yaml)
### 变量

模板语法
```
  - log: '{{r}} origin format'
  - log: ${r} shell format
```

返回值
```
  - math.floor: 3.2
  - return: r
  - assert: [ ${r}, 3 ]
```

### 断言

assert断言
```
  - math.floor: 3.2
  - return: r
  - assert:
      real: ${r}
      expect: '3'
  - assert: [ ${r}, '3' ]
#推荐用法
  - assert: ${true if r==3}
```

### 导入

会自动导入需要的包

```yaml
#导入系统包
test_import:
  - math.floor: 3.2
  - return: r
  - assert: ${true if r==3}

#导入第三方包
  - sys.path.append: ../../
  - assert: [ '${sys.path[-1]}', ../../ ]

#类初始化例子
test_init:
  - core.testcase.TestCase: [[]]
  - return: t
  - log: ${t}
```


### 数据读取todo

```yaml
- params:
    username: ${ [e['name'] for e in e['sheet 1'][3:]] }

- excel: 1.csv
- return: e
- log: ${data("sheet1", e['sheet1'])}
- assert: ${ e['sheet 1'][0:]['header'] == 3 }
- assert: ${ [e['name'] for e in e['sheet 1'][3:]] }

- excel: 2.xles, sheet1
- return: s1
```

## 执行用例

```bash
pytest tests/test_ddd.py --testcase tests/
```
## changelog

### todo
- mock
- excel: 1.xels

list[dict]

dict[list[dict]]


## 更多详细介绍
[docs/README.md](docs/README.md)
